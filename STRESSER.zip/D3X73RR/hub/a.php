<?php
$t=time();
echo($t . "<br>");
echo(date("Y-m-d",$t));
?>